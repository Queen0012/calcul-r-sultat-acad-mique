#include <stdio.h>

// Donn�es de l'�tudiant
#define N_MATIERES 13
int credits[N_MATIERES] = {5,0,5,0,6,0,6,0,3,0,5};
char* noms_matieres[N_MATIERES] = {
    "Analyse1",
    "Algebre1",
    "Electricite1",
    "Architecture1",
    "Algorithmique",
    "Programmation",
    "Systemes d'exploitation1",
    "Initiation aux reseaux",
    "Introduction a l'economie",
    "Introduction au droit",
    "Communication1",
    "Anglais1",
    "Arabe1"
};


// Fonctions auxiliaires
float moyenne(float controle, float session) {
    return 0.4 * controle + 0.6 * session;
}
float moyenne1(float controle, float session, float TP) {
    return 0.2 * controle + 0.2 * session + 0.6 * TP ;
}

// Programme principal
int main() {
    float notes[N_MATIERES][2]; // Notes de chaque mati�re
    float notesrattapage[N_MATIERES][1]; // Notes de Rattrapage
    float TP;
    char sexe;
    char matiere_acro[13];
    char matieres_acro[13];
    char prenom_etudiant;
    char nom_etudiant;
    char* inco[13]={"","","","","","","","","","","","",""};
    float moyennes[N_MATIERES]; // Moyennes de chaque mati�re
    int crditsob;
    float moyenne_generalS1[13];


    //Saisie du Nom de l'etudiant
    printf("Salut! \n");



    // Saisie des notes et calcules des moyennes S1...
printf("Commencer la saisie de vos notes du premier semestre\n\n");

    for (int i = 0; i < N_MATIERES; i++) {
            if(i==5){
                    do{
                            printf("Entre une note entre 0 et 20\n");
                     printf("Matiere %s  :\n", noms_matieres[i]);
        printf("- Note de controle : ");
        scanf("%f", &notes[i][0]);
        printf("- Note de TP : ");
          scanf("%f", &TP);
        printf("- Note de session : ");
        scanf("%f", &notes[i][1]);}
        while((notes[i][0]>20)||(notes[i][1]>20)||(TP>20));
        moyennes[i] = moyenne1(notes[i][0], TP, notes[i][1]);
        printf("Moyenne : %.2f\n\n", moyennes[i]);

            }
            else{
                    do{
        printf("Entre une note entre 0 et 20\n");
        printf("Matiere %s  :\n", noms_matieres[i]);
        printf("- Note de controle : ");
        scanf("%f", &notes[i][0]);
        printf("- Note de session : ");
        scanf("%f", &notes[i][1]);}
         while((notes[i][0]>20)||(notes[i][1]>20));
        moyennes[i] = moyenne(notes[i][0], notes[i][1]);
        printf("Moyenne : %.2f\n\n", moyennes[i]);
        }
    }

 // Recompanse et Rattrapages
 for (int i = 0; i < N_MATIERES; i+=2) {
if(i==10){
if ((moyennes[i] +  moyennes[i+1]+moyennes[i+2])/3<10){
            if((moyennes[i]<8)&&(moyennes[i+1]<8)&&(moyennes[i+2]<8)){
            printf("Matiere %s  :\n", noms_matieres[i]);
            printf("- Note de Rattrapage: ");
            scanf("%f", &notesrattapage[i][0]);
            if(notesrattapage[i][0]>notes[i][1]){
            notes[i][1]=notesrattapage[i][0];}
             printf("Matiere %s  :\n", noms_matieres[i+1]);
            printf("- Note de Rattrapage: ");
            scanf("%f", &notesrattapage[i+1][0]);
            if(notesrattapage[i+1][0]>notes[i+1][1]){
                   notes[i+1][1]=notesrattapage[i+1][0];}
             printf("Matiere %s  :\n", noms_matieres[i+2]);
            printf("- Note de Rattrapage: ");
            scanf("%f", &notesrattapage[i+2][0]);}
             else if(moyennes[i]<8){
                  printf("Matiere %s  :\n", noms_matieres[i]);
                  printf("- Note de Rattrapage : ");
                  scanf("%f", &notesrattapage[i][0]);
                  if(notesrattapage[i][0]>notes[i][1]){
                           notes[i][1]=notesrattapage[i][0];}}
            else if(moyennes[i+1]<8){
                 printf("Matiere %s  :\n", noms_matieres[i+1]);
                  printf("- Note de Rattrapage: ");
                  scanf("%f", &notesrattapage[i+1][0]);
                if(notesrattapage[i+1][0]>notes[i+1][1]){
                   notes[i+1][1]=notesrattapage[i+1][0];}

        }
        else if(moyennes[i+2]<8){
                 printf("Matiere %s  :\n", noms_matieres[i+2]);
                  printf("- Note de Rattrapage: ");
                  scanf("%f", &notesrattapage[i+2][0]);
                if(notesrattapage[i+2][0]>notes[i+2][1]){
                   notes[i+2][1]=notesrattapage[i+2][0];}

        }
        }
if ((moyennes[i] +  moyennes[i+1]+moyennes[i+2])/3>=10){
         if((moyennes[i]<8)){
            printf("Matiere %s  :\n", noms_matieres[i]);
            printf("- Note de Rattrapage: ");
            scanf("%f", &notesrattapage[i][0]);
            if(notesrattapage[i][0]>notes[i][1]){
            notes[i][1]=notesrattapage[i][0];}}
        else if(moyennes[i+1]<8){
             printf("Matiere %s  :\n", noms_matieres[i+1]);
            printf("- Note de Rattrapage: ");
            scanf("%f", &notesrattapage[i+1][0]);
            if(notesrattapage[i+1][0]>notes[i+1][1]){
                   notes[i+1][1]=notesrattapage[i+1][0];}}
        else if(moyennes[i+1]<8){printf("Mati�re %s  :\n", noms_matieres[i+2]);
                  printf("- Note de Rattrapage: ");
                  scanf("%f", &notesrattapage[i+2][0]);
                if(notesrattapage[i+2][0]>notes[i+2][1]){
                   notes[i+2][1]=notesrattapage[i+2][0];}}
        }


        }
else if ((moyennes[i] +  moyennes[i+1])/2<10){
        if((moyennes[i]<8)&&(moyennes[i+1]<8)){
            printf("Matiere %s  :\n", noms_matieres[i]);
            printf("- Note de Rattrapage: ");
            scanf("%f", &notesrattapage[i][0]);
            if(notesrattapage[i][0]>notes[i][1]){
                   notes[i][1]=notesrattapage[i][0];}

            printf("Matiere %s  :\n", noms_matieres[i+1]);
            printf("- Note de Rattrapage: ");
            scanf("%f", &notesrattapage[i+1][0]);
            if(notesrattapage[i+1][0]>notes[i+1][1]){
                   notes[i+1][1]=notesrattapage[i+1][0];}}
                    else if((moyennes[i]<10)&&(moyennes[i+1]<10)){
                  printf("Matiere %s  :\n", noms_matieres[i]);
                  printf("- Note de Rattrapage : ");
                  scanf("%f", &notesrattapage[i][0]);
                  if(notesrattapage[i][0]>notes[i][1]){
                           notes[i][1]=notesrattapage[i][0];}
                 printf("Matiere %s  :\n", noms_matieres[i+1]);
                  printf("- Note de Rattrapage: ");
                  scanf("%f", &notesrattapage[i+1][0]);
                if(notesrattapage[i+1][0]>notes[i+1][1]){
                   notes[i+1][1]=notesrattapage[i+1][0];}}

          else if(moyennes[i]<8){
                  printf("Matiere %s  :\n", noms_matieres[i]);
                  printf("- Note de Rattrapage : ");
                  scanf("%f", &notesrattapage[i][0]);
                  if(notesrattapage[i][0]>notes[i][1]){
                           notes[i][1]=notesrattapage[i][0];}


                      }
        else if(moyennes[i+1]<8){
                 printf("Matiere %s  :\n", noms_matieres[i+1]);
                  printf("- Note de Rattrapage: ");
                  scanf("%f", &notesrattapage[i+1][0]);
                if(notesrattapage[i+1][0]>notes[i+1][1]){
                   notes[i+1][1]=notesrattapage[i+1][0];}

        }

        }

else if((moyennes[i]+  moyennes[i+1])/2>=10){
                 if(moyennes[i]<8){
                  printf("Matiere %s  :\n", noms_matieres[i]);
                  printf("- Note de Rattrapage : ");
                  scanf("%f", &notesrattapage[i][0]);
                   if(notesrattapage[i][0]>notes[i][1]){
                           notes[i][1]=notesrattapage[i][0];}
       }
       else if(moyennes[i+1]<8){
                 printf("Matiere %s  :\n", noms_matieres[i+1]);
                  printf("- Note de Rattrapage: ");
                  scanf("%f", &notesrattapage[i+1][0]);
                   if(notesrattapage[i+1][0]>notes[i+1][1]){
                           notes[i+1][1]=notesrattapage[i+1][0];}



        }
      }
      }

//calcule de moyenne apres rattrapage
        for (int i = 0; i < N_MATIERES; i++) {
            if(i==5){
                     moyennes[i] = moyenne1(notes[i][0], TP, notes[i][1]);
                      }
            else{
                moyennes[i] = moyenne(notes[i][0], notes[i][1]);

            }}

for (int i = 0; i < N_MATIERES; i+=2){
     if(i==10){
        moyenne_generalS1[i]=(moyennes[i]+moyennes[i+1]+moyennes[i+2])/3;
     }
    else{ moyenne_generalS1[i]=(moyennes[i]+moyennes[i+1])/2;
}}

 //Affichage du resultat S1...
printf("Matiere                                         CC               TP             ET            MOYENNE        MOYENNE_GENERALE");
 printf("\n-------------------------------------------------------------------------------------------------------------------------------------");


  for (int i = 0; i < N_MATIERES; i++){
    printf("\n");
    if(i==8)printf("%s\t\t",noms_matieres[i]);
    if(i==6)printf("%s\t\t",noms_matieres[i]);
    if((i==9)||(i==7))printf("%s\t\t\t",noms_matieres[i]);
    if((i==2)||(i==4)||(i==5)||(i==3)||(i==10)) printf("%s\t\t\t\t",noms_matieres[i]);
    if((i==0)||(i==1)||(i==11))printf("%s\t\t\t\t",noms_matieres[i]);
    if(i==12)printf("%s\t\t\t\t\t",noms_matieres[i]);
     printf("\t%.2f\t",notes[i][0]);
     if(i==5){
         printf("\t%.2f\t",TP);
     }
     else{
         printf("\t%.2f\t",inco[i]);
     }
     printf("\t%.2f\t",notes[i][1]);
     printf("\t%.2f\t", moyennes[i]);
       printf("\t%.2f\t\n", moyenne_generalS1[i]);
       printf("\n-------------------------------------------------------------------------------------------------------------------------------------");

      }


//calcul de credits
 for (int i = 0; i < N_MATIERES; i+=2){
        if(i==10){
            if(((moyennes[i]+  moyennes[i+1]+ moyennes[i+2])/3>=10)&&(  moyennes[i]>=8)&&(moyennes[i+1]>=8)&&(moyennes[i+2]>=8)){
                   crditsob+=credits[i];

                  matiere_acro[i]=noms_matieres[i];
                  matiere_acro[i+1]=noms_matieres[i+1];
                  matiere_acro[i+2]=noms_matieres[i+2];}}

        else if  (((moyennes[i]+  moyennes[i+1])/2>=10)&&(  moyennes[i]>=8)&&(  moyennes[i+1]>=8)){
                     crditsob+=credits[i];
                      matieres_acro[i]=noms_matieres[i];
                      matieres_acro[i+1]=noms_matieres[i+1];
    }}

  printf("\nVous avez %d/30 credits au premier semestre\n ",  crditsob);

  //Declaration de variable
   float note[N_MATIERES][2]; // Notes de chaque mati�re
    float noterattapage[N_MATIERES][1]; // Notes de Rattrapage
    float tp[13];
    float moyennesS2[N_MATIERES]; // Moyennes de chaque mati�re
    int credits_obten[N_MATIERES]; // Cr�dits obtenus pour chaque mati�re
    int crditobtnu=0;
     int cr_fi;
     char matieres_acrose[13];
    char matieres_acros[13];
     int  S2_credit[13]={5,0,4,0,6,0,6,0,6,0,3,0};
    float moyenne_generaleS2[13];
    char* S2_Matieres[N_MATIERES] = {
    "Analyse2",
    "Algebre2",
    "Electronique Analogique",
    "Architecture2",
    "Structure de donnees lineaire",
    "Programmation procedurale",
    "Systemes d'information",
    "Developpement Web1",
    "Introduction au SGBD",
    "Architecture reseau",
    "Systeme d'exploitation2",
    "Communication2",
    "Anglais2",
};
// Saisie des notes et calcules des moyennes S2...
printf("Commencer la saisie de vos notes du deuxieme semestre\n\n");


    for (int i = 0; i < N_MATIERES; i++) {
            if((i==5)||(i==7)){
                    do{
        printf("Entre une note entre 0 et 20\n");
        printf("Matiere %s  :\n", S2_Matieres[i]);
        printf("- Note de controle : ");
        scanf("%f", &note[i][0]);
        printf("- Note de TP : ");
          scanf("%f", &tp[i]);
        printf("- Note de session : ");
        scanf("%f", &note[i][1]);}
      while((note[i][0]>20)||(note[i][1]>20)||(tp[i]>20));
        moyennesS2[i] = moyenne1(note[i][0], tp[i], notes[i][1]);
        printf("Moyenne : %.2f\n\n", moyennesS2[i]);

            }
            else{
                do{
        printf("Entre une note entre 0 et 20\n");
        printf("Matiere %s  :\n", S2_Matieres[i]);
        printf("- Note de controle : ");
        scanf("%f", &note[i][0]);
        printf("- Note de session : ");
        scanf("%f", &note[i][1]);}
         while((note[i][0]>20)||(note[i][1]>20));
        moyennesS2[i] = moyenne(note[i][0], note[i][1]);
        printf("Moyenne : %.2f\n\n", moyennesS2[i]);
        }
    }
//Recompanse et rattrapage
for (int i = 0; i < N_MATIERES; i+=2) {
if(i==6){
if ((moyennesS2[i] +  moyennesS2[i+1]+moyennesS2[i+2])/3<10){
            if((moyennesS2[i]<8)&&(moyennesS2[i+1]<8)&&(moyennesS2[i+2]<8)){
            printf("Matiere %s  :\n", S2_Matieres[i]);
            printf("- Note de Rattrapage: ");
            scanf("%f", &noterattapage[i][0]);
            if(noterattapage[i][0]>note[i][1]){
            note[i][1]=noterattapage[i][0];}
             printf("Matiere %s  :\n", S2_Matieres[i+1]);
            printf("- Note de Rattrapage: ");
            scanf("%f", &noterattapage[i+1][0]);
            if(noterattapage[i+1][0]>note[i+1][1]){
                   note[i+1][1]=noterattapage[i+1][0];}
             printf("Matiere %s  :\n", S2_Matieres[i+2]);
            printf("- Note de Rattrapage: ");
            scanf("%f", &noterattapage[i+2][0]);}
             else if(moyennesS2[i]<8){
                  printf("Matiere %s  :\n", S2_Matieres[i]);
                  printf("- Note de Rattrapage : ");
                  scanf("%f", &noterattapage[i][0]);
                  if(noterattapage[i][0]>note[i][1]){
                           note[i][1]=noterattapage[i][0];}}
            else if(moyennesS2[i+1]<8){
                 printf("Matiere %s  :\n", S2_Matieres);
                  scanf("%f", &noterattapage[i+1][0]);
                if(noterattapage[i+1][0]>note[i+1][1]){
                   note[i+1][1]=noterattapage[i+1][0];}

        }
        else if(moyennesS2[i+2]<8){
                 printf("Matiere %s  :\n",S2_Matieres[i+2]);
                  printf("- Note de Rattrapage: ");
                  scanf("%f", &noterattapage[i+2][0]);
                if(noterattapage[i+2][0]>note[i+2][1]){
                   note[i+2][1]=noterattapage[i+2][0];}

        }
        }
if ((moyennesS2[i] +  moyennesS2[i+1]+moyennesS2[i+2])/3>=10){
         if((moyennesS2[i]<8)){
            printf("Matiere %s  :\n", S2_Matieres[i]);
            printf("- Note de Rattrapage: ");
            scanf("%f", &noterattapage[i][0]);
            if(noterattapage[i][0]>note[i][1]){
            note[i][1]=noterattapage[i][0];}}
        else if(moyennesS2[i+1]<8){
             printf("Matiere %s  :\n", S2_Matieres[i+1]);
            printf("- Note de Rattrapage: ");
            scanf("%f", &noterattapage[i+1][0]);
            if(noterattapage[i+1][0]>notes[i+1][1]){
                   note[i+1][1]=noterattapage[i+1][0];}}
        else if(moyennesS2[i+1]<8){printf("Mati�re %s  :\n", S2_Matieres[i+2]);
                  printf("- Note de Rattrapage: ");
                  scanf("%f", &noterattapage[i+2][0]);
                if(noterattapage[i+2][0]>note[i+2][1]){
                   note[i+2][1]=noterattapage[i+2][0];}}
        }


       i++; }
else if ((moyennesS2[i] +  moyennesS2[i+1])/2<10){
        if((moyennesS2[i]<8)&&(moyennesS2[i+1]<8)){
            printf("Matiere %s  :\n", S2_Matieres[i]);
            printf("- Note de Rattrapage: ");
            scanf("%f", &noterattapage[i][0]);
            if(noterattapage[i][0]>note[i][1]){
                   note[i][1]=noterattapage[i][0];}

            printf("Matiere %s  :\n", S2_Matieres[i+1]);
            printf("- Note de Rattrapage: ");
            scanf("%f", &noterattapage[i+1][0]);
            if(noterattapage[i+1][0]>note[i+1][1]){
                   note[i+1][1]=noterattapage[i+1][0];}}
                    else if((moyennesS2[i]<10)&&(moyennesS2[i+1]<10)){
                  printf("Matiere %s  :\n", S2_Matieres[i]);
                  printf("- Note de Rattrapage : ");
                  scanf("%f", &noterattapage[i][0]);
                  if(noterattapage[i][0]>note[i][1]){
                           note[i][1]=noterattapage[i][0];}
                 printf("Matiere %s  :\n", S2_Matieres[i+1]);
                  printf("- Note de Rattrapage: ");
                  scanf("%f", &noterattapage[i+1][0]);
                if(noterattapage[i+1][0]>note[i+1][1]){
                   note[i+1][1]=noterattapage[i+1][0];}}

          else if(moyennesS2[i]<8){
                  printf("Matiere %s  :\n", S2_Matieres[i]);
                  printf("- Note de Rattrapage : ");
                  scanf("%f", &noterattapage[i][0]);
                  if(noterattapage[i][0]>note[i][1]){
                           note[i][1]=noterattapage[i][0];}


                      }
        else if(moyennesS2[i+1]<8){
                 printf("Matiere %s  :\n", S2_Matieres[i+1]);
                  printf("- Note de Rattrapage: ");
                  scanf("%f", &noterattapage[i+1][0]);
                if(noterattapage[i+1][0]>note[i+1][1]){
                   note[i+1][1]=noterattapage[i+1][0];}

        }

        }

else if((moyennesS2[i]+  moyennesS2[i+1])/2>=10){
                 if(moyennesS2[i]<8){
                  printf("Matiere %s  :\n", S2_Matieres[i]);
                  printf("- Note de Rattrapage : ");
                  scanf("%f", &noterattapage[i][0]);
                   if(noterattapage[i][0]>note[i][1]){
                           note[i][1]=noterattapage[i][0];}
       }
       else if(moyennesS2[i+1]<8){
                 printf("Matiere %s  :\n", S2_Matieres[i+1]);
                  printf("- Note de Rattrapage: ");
                  scanf("%f", &noterattapage[i+1][0]);
                   if(noterattapage[i+1][0]>note[i+1][1]){
                           note[i+1][1]=noterattapage[i+1][0];}



        }
      }
      }


//calcule de moyenne apres rattrapage de S2...
for (int i = 0; i < N_MATIERES; i++) {
            if((i==5)||(i==7)){
                     moyennesS2[i] = moyenne1(note[i][0], tp[i], note[i][1]);
                      }
                        else{
                moyennesS2[i] = moyenne(note[i][0], note[i][1]);

            }}
for (int i = 0; i < N_MATIERES; i++){
    if(i==6){
    if(((moyennesS2[i]+  moyennesS2[i+1]+ moyennesS2[i+2])/3>=10)&&(  moyennesS2[i]>=8)&&(moyennesS2[i+1]>=8)&&(moyennesS2[i+2]>=8)){
                    crditobtnu+= S2_credit[i];

                   i++;}}
        else if  (((moyennesS2[i]+  moyennesS2[i+1])/2>=10)&&(  moyennesS2[i]>=8)&&(  moyennesS2[i+1]>=8)){
                     crditobtnu+= S2_credit[i];
                     }}

    for (int i = 0; i < N_MATIERES; i+=2){
   if(i==6){
        moyenne_generaleS2[i]=(moyennesS2[i]+moyennesS2[i+1]+moyennesS2[i+2])/3;
        i++;
     }
    else{ moyenne_generaleS2[i]=(moyennesS2[i]+moyennesS2[i+1])/2;
}}
printf("Matiere                                         CC               TP             ET            MOYENNE        MOYENNE_GENERALE");
 printf("\n-------------------------------------------------------------------------------------------------------------------------------------");

    for (int i = 0; i < N_MATIERES; i++){
    printf("\n");
    if(i==8)printf("%s\t\t\t",S2_Matieres[i]);
    if(i==6)printf("%s\t\t\t",S2_Matieres[i]);
    if((i==9)||(i==7))printf("%s\t\t\t",S2_Matieres[i]);
    if((i==2)||(i==10) ) printf("%s\t\t\t",S2_Matieres[i]);
    if((i==0)||(i==1)||(i==11))printf("%s\t\t\t\t",S2_Matieres[i]);
    if(i==12)printf("%s\t\t\t\t",S2_Matieres[i]);
    if(i==3)printf("%s\t\t\t\t",S2_Matieres[i]);
    if((i==4)||(i==5)) printf("%s\t\t",S2_Matieres[i]);
    printf("\t%.2f\t",note[i][0]);
     printf("\t%.2f\t",tp[i]);
     printf("\t%.2f\t",note[i][1]);
     printf("\t%.2f\t",moyennesS2[i]);
     printf("\t%.2f\t",moyenne_generaleS2[i]);
      printf("\n-------------------------------------------------------------------------------------------------------------------------------------");
  }
     printf("\nVous avez %d/30 credits en Semestre2\n",crditobtnu);
cr_fi=crditobtnu+crditsob;
printf("\nVous avez %d/60 credit au total \n ",cr_fi);
if(cr_fi==60)printf("\nVous avez valider l'annee avec succee");
else if((cr_fi<54)&&(cr_fi>=43)){printf("\nVous ete ajourne");
for (int i = 0; i < N_MATIERES; i++){
    printf("%s%s%s%s",matieres_acrose[i],matieres_acros[i], matiere_acro[i], matieres_acro[i]);}}
else if((cr_fi>=54)&&(cr_fi<60)){printf("\nVous avez valider l'annee avec dette de matieres");
        for (int i = 0; i < N_MATIERES; i++){
    printf("%s%s%s%s",matieres_acrose[i],matieres_acros[i], matiere_acro[i], matieres_acro[i]);}}
else printf("\n\n\n\nVous ete exclus de l'ENASTIC suite a votre insufisance de credits");
return 0;}
